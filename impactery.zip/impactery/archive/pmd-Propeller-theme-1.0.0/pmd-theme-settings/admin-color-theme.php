
<?php if( have_rows('color_theme', 'option') ): ?>
<?php while( have_rows('color_theme', 'option') ): the_row(); ?>

/* Background Color Primary RGB */
/* Background Color Secondary RGB */
/* Color Primary RGB */
/* Color Secondary RGB */
/* Background Color Primary and Secondary RGB */



/* --------------------------
	Primary Color 
----------------------------- */
.bg-primary {background: <?php the_sub_field('primary_color','option');?> !important;}
.text-primary, a.text-primary:focus, a.text-primary:hover {color: <?php the_sub_field('primary_color','option');?> !important;}
.btn-outline-primary, .outlineBadges-badge-primary {color: <?php the_sub_field('primary_color','option');?>; border-color: <?php the_sub_field('primary_color','option');?>;}
.boosterPacks .pmd-card.model-basic.model-recommended {border-color: <?php the_sub_field('primary_color','option');?>;}
.btn-primary, .btn-outline-primary:hover, .btn-outline-primary:not(:disabled):not(.disabled).active, .btn-outline-primary:not(:disabled):not(.disabled):active {border-color: <?php the_sub_field('primary_color','option');?>; background: <?php the_sub_field('primary_color','option');?>;}
.pmd-card-carousel.owl-carousel .owl-nav button.owl-next:after, .pmd-card-carousel.owl-carousel .owl-nav button.owl-prev:after, .pmd-card .pmd-card-media.pmd-floating-wrapper .floating-content-date {color: <?php the_sub_field('primary_color','option');?>;}
.pmd-card-carousel.owl-carousel .owl-nav button.owl-prev:hover, .pmd-card-carousel.owl-carousel .owl-nav button.owl-prev:active, .pmd-card-carousel.owl-carousel .owl-nav button.owl-next:hover, .pmd-card-carousel.owl-carousel .owl-nav button.owl-next:active {background:<?php the_sub_field('primary_color','option');?>;}
.btn-primary.pmd-btn-flat, .btn-primary.pmd-btn-flat:not(:disabled):not(.disabled).active, .btn-primary.pmd-btn-flat:not(:disabled):not(.disabled):active {color: <?php the_sub_field('primary_color','option');?>;}
.btn-primary.pmd-btn-flat:hover {color: <?php the_sub_field('primary_color','option');?> !important;}
<?php if(get_sub_field('primary_color','option')):?>

.pmd-contact-section .pmd-contact-form input:-webkit-autofill,
.pmd-contact-section .pmd-contact-form input:-webkit-autofill:active,
.pmd-contact-section .pmd-contact-form input:-webkit-autofill:focus,
.pmd-contact-section .pmd-contact-form input:-webkit-autofill:hover { -webkit-box-shadow: 0 0 0 30px <?php the_sub_field('primary_color','option');?> inset !important;}
.experts-section .footer-social-icons .pmd-social-icon svg .st0, .experts-section .footer-social-icons .pmd-social-icon svg .st1, .experts-section .footer-social-icons .pmd-social-icon svg .st2 {fill: <?php the_sub_field('primary_color','option');?> !important;}
<?php endif; ?>
/* --------------------------
	Secondary Color 
----------------------------- */
.bg-secondary {background: <?php the_sub_field('secondary_color','option');?> !important;}
.pmd-navbar.navbar-light .navbar-nav .active>.nav-link, .pmd-navbar.navbar-light .navbar-nav .nav-link.active, .pmd-navbar.navbar-light .navbar-nav .nav-link.show, .pmd-navbar.navbar-light .navbar-nav .show>.nav-link, .pmd-navbar.navbar-light .navbar-nav .nav-link:focus, .pmd-navbar.navbar-light .navbar-nav .nav-link:hover {color: <?php the_sub_field('secondary_color','option');?>;}
.questionnaire:before, .pmd-card .pmd-title-separator:after, .pmd-contact-section .title-separator {background: <?php the_sub_field('secondary_color','option');?>;}
.text-secondary, a.text-secondary:focus, a.text-secondary:hover { color: <?php the_sub_field('secondary_color','option');?> !important;}
.outlineBadges-badge-secondary, .btn-outline-secondary { border-color: <?php the_sub_field('secondary_color','option');?>; color: <?php the_sub_field('secondary_color','option');?>;}
.btn-secondary, .btn-secondary .ink, .btn-outline-secondary .ink, .btn-secondary:hover, .btn-secondary:not(:disabled):not(.disabled).active, .btn-secondary:not(:disabled):not(.disabled):active, .show>.btn-secondary.dropdown-toggle, .btn-outline-secondary:hover, .btn-outline-secondary:not(:disabled):not(.disabled).active, .btn-outline-secondary:not(:disabled):not(.disabled):active {border-color: <?php the_sub_field('secondary_color','option');?>; background: <?php the_sub_field('secondary_color','option');?>;}
.subscription-plans .pmd-card.plan-basic.plan-recommended {border-color: <?php the_sub_field('secondary_color','option');?>;}
.address-list .st2 {fill: <?php the_sub_field('secondary_color','option');?>;}
.inner-page-title {background: <?php the_sub_field('secondary_color','option');?>;}

@media screen and (max-width: 991px) {
	.questionnaire .question-content {background: <?php the_sub_field('secondary_color','option');?>;}
}


/* --------------------------
	Text primary Color
----------------------------- */
.pmd-navbar.navbar-light .navbar-nav .nav-link, .h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 { color: <?php the_sub_field('primary_text_color','option');?>}

/* --------------------------
	Text secondary Color
----------------------------- */
body {color: <?php the_sub_field('secondary_text_color','option');?>}

<?php endwhile; ?>
<?php endif; ?>
<?php if( have_rows('font_family', 'option') ): ?>
<?php while( have_rows('font_family', 'option') ): the_row(); 
	$bodyfont =  get_sub_field('font_family_body','option');
	$titlefont =  get_sub_field('font_family_title','option');
?>
body {font-family:"<?php echo $bodyfont['font'];?>";}
h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6, .btn, .pmd-navbar.navbar-light .navbar-nav .nav-link, .pmd-footer-dark .pmd-site-info a, .pmd-footer-dark .pmd-site-info strong {font-family:"<?php echo $titlefont['font'];?>";}
<?php endwhile; ?>
<?php endif; ?>