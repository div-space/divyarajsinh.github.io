<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package pmd
 */

?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<!-- Hub Card -->
		<div class="card pmd-card">
			<div class="card-body d-flex flex-row">
				<div class="media-body">
					<h6 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
					<p class="card-subtitle mb-3">By <strong><?php the_author(); ?></strong> on <?php the_date(); ?></p>
					<p class="card-text"><?php the_excerpt(); ?></p>					
					<a href="<?php the_permalink(); ?>" class="btn btn-primary pmd-btn-raised pmd-ripple-effect btn-sm">ReadMore</a>
				</div>
				<?php if ( has_post_thumbnail() ) { ?>
					<img src="<?php the_post_thumbnail_url('thumbnail'); ?>" class="ml-3" height="150" width="150" alt="<?php the_title(); ?>">
				<?php } else { ?>
					<?php echo '<img class="ml-3" src="' . get_bloginfo( 'stylesheet_directory' )  . '/assets/images/default-post-thumbnail.jpg" height="150" width="150" />'; ?>
				<?php } ?>
			</div>
		</div><!-- End - Hub Card -->
	</article><!-- #post-<?php the_ID(); ?> -->