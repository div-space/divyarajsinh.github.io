<?php
/**
 * Template part for displaying page content in page-modules.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package pmd
 */

?>
<section class="">
	<article id="post-<?php the_ID(); ?>" <?php post_class('module-post'); ?>>

		<!-- Post Title -->
		<div class="module-post-title">
			<div class="container">
				<div class="row">
					<div class="col-lg-9">

						<!-- Title -->
						<?php if (is_singular()) :
							the_title('<h1 class="h2">', '</h1>');
						else :
							the_title('<h2 class="h2"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
						endif; ?>						

						<!-- Module Price -->
						<?php
							$price = get_field('price');
							if ($price === "free") :
								$badgeColor = 'outlineBadges-badge-primary';
							else :
								$badgeColor = 'outlineBadges-badge-secondary';
							endif;
							?>
							<span class="outlineBadges text-uppercase <?php echo $badgeColor;  ?>"><?php the_field('price') ?></span>							

					</div>
					<div class="col-lg-3">

						<!-- Actions -->
						<p class="mb-3">
							<button title="Add to Favourite" class="mr-2 btn btn-sm pmd-ripple-effect btn-outline-primary pmd-btn-fab" data-toggle="button"><i class="material-icons pmd-sm">star_border</i></button>
							Add to favourite this
						</p>
						<a href="<?php the_field('button_url') ?>" class="btn pmd-btn-raised pmd-ripple-effect btn-secondary d-block"><?php the_field('button_label') ?></a>
						
					</div>
				</div>
			</div>
		</div>
		<!-- End Post Title -->

		<div class="module-post-body section">
			<div class="container">
				<div class="row">
					<div class="col-lg-8">

						<!-- Module Feature Image -->
						<?php $eventImageUrl = wp_get_attachment_url(get_post_thumbnail_id($post->ID), 'thumbnail'); ?>
						<?php $eventImageAlt = get_post_meta(get_post_thumbnail_id($post->ID), '_wp_attachment_image_alt', true); ?>
						<div class="mb-4 pmd-card-media">
							<?php if (has_post_thumbnail($post->ID)) : ?>
								<img class="img-fluid rounded" src="<?php echo $eventImageUrl; ?>" alt="<?php echo $eventImageAlt; ?>">
							<?php else : ?>
								<img class="img-fluid rounded" src="<?php echo get_template_directory_uri(); ?>/assets/images/card_placeholder.jpg" alt="Placeholder Image">
							<?php endif; ?>
						</div>

						<!-- Post Content -->
						<div class="entry-content mb-4">
							<h5 class="">Details</h5>
							<?php the_content(sprintf(
								wp_kses(
									__('Continue reading<span class="screen-reader-text"> "%s"</span>', 'pmd'),
									array(
										'span' => array(
											'class' => array(),
										),
									)
								),
								get_the_title()
							));

							wp_link_pages(array(
								'before' => '<div class="page-links">' . esc_html__('Pages:', 'pmd'),
								'after'  => '</div>',
							));
							?>
						</div>

					</div>

					<div class="col-lg-4 module-info">
						<div class="card pmd-card">
							<div class="card-body">
								<!-- Date and Time -->
								<div class="mb-3">
									<h5>Date and Time</h5>
									<p class="media card-subtitle mb-2">
										<i class="material-icons mr-2">access_time</i>
										<span class="media-body"><?php the_field('select_date'); ?>, <?php the_field('start_time'); ?> to <?php the_field('end_time'); ?></span>
									</p>
								</div>
								
								<!-- Address -->
								<div class="mb-3">
									<h5>Venue</h5>
									<p class="card-subtitle media">
										<i class="material-icons mr-2">location_on</i>
										<span class="media-body"><?php the_field('address'); ?></span>
									</p>
								</div>
								<?php $location = get_field('location_map');
								if (!empty($location)) : ?>
									<h5>Location</h5>
									<div class="acf-map">
										<div class="marker" data-lat="<?php echo $location['lat']; ?>" data-lng="<?php echo $location['lng']; ?>"></div>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Next and Prev posts -->
			<div class="container prev-next-module">
				<div class="row">
					<div class="col-lg-12">
						<h5 class="">Other Modules</h5>
					</div>
					<?php
						$prev_post = get_previous_post();
						if($prev_post) {
							$prev_title = strip_tags(str_replace('"', '', $prev_post->post_title));
							echo "\t" . '<div class="col-12 col-lg"><div class="card pmd-card"><div class="card-body"><a rel="prev" href="' . get_permalink($prev_post->ID) . '" title="' . $prev_title. '" class="text-primary media"><i class="material-icons mr-2 align-self-center">keyboard_arrow_left</i><span class="media-body">'. $prev_title . '</span></a></div></div></div>' . "\n";
						}

						$next_post = get_next_post();
						if($next_post) {
							$next_title = strip_tags(str_replace('"', '', $next_post->post_title));
							echo "\t" . '<div class="col-12 col-lg"><div class="card pmd-card"><div class="card-body"><a rel="next" href="' . get_permalink($next_post->ID) . '" title="' . $next_title. '" class="text-primary media"><span class="media-body">'. $next_title . '</span><i class="material-icons ml-2 align-self-center">keyboard_arrow_right</i></a></div></div></div>' . "\n";
						}
					?>			
				</div>
			</div>

		</div>
		<footer class="entry-footer">
			<?php pmd_entry_footer(); ?>
		</footer>
		<!-- .entry-footer -->

	</article>
	<!-- #post-<?php the_ID(); ?> -->
	
	

</section>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBoM1ePced26bN1LbtK2J0csGLq5KaQLNA"></script>